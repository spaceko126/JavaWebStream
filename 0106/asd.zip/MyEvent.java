public interface MyEvent {
    public void listen(String name);
}