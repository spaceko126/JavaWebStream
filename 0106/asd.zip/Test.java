public class Test {
	public static void main(String[] args) throws Exception {
		
		Thread thread1 = new MyThread("Thread1",1, new MyEventListener());
		MyThread thread2 = new MyThread(11,new MyEventListener());
		MyThread thread3 = new MyThread("Thread3",new MyEventListener());
		MyThread thread4 = new MyThread(new MyEventListener());

		thread1.start();
		thread2.start();
		thread3.start();
		thread4.start();	
	}
}

class MyEventListener implements MyEvent{
	public void listen(String name) {
		System.out.println(name+"이(가)절반이 실행되었습니다");
	}
}